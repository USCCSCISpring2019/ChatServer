package com.mypackage;

import java.util.ArrayList;
import java.util.Iterator;

public class GameBoard {
	String gameBoard[][] = null;
	ArrayList<String> hintsAcross = null;
	ArrayList<String> hintsDown = null;
	
	public static void main(String[] args) {
		
		GameBoard gb = new GameBoard();
		String temp = gb.printBoard();
		System.out.print(temp);
		gb.correctguess("gold");
		temp = gb.printBoard();
		System.out.print(temp);
		gb.correctguess("MARSHALL");
		temp = gb.printBoard();
		System.out.print(temp);
		gb.correctguess("trojans");
		temp = gb.printBoard();
		System.out.print(temp);
		gb.correctguess("traveler");
		gb.correctguess("csci");
		gb.correctguess("dodgers");
		temp = gb.printBoard();
		System.out.print(temp);
		
		
	}
	
	public GameBoard() {
		hintsAcross = new ArrayList<String>();
		hintsDown = new ArrayList<String>();
		
		hintsAcross.add("Across");
		hintsAcross.add("1 What is USC’s mascot?");
		hintsAcross.add("2 What professional baseball team is\n" + 
				"closest to USC?");
		hintsAcross.add("3 What is the four-letter prefix for\n" + 
				"Computer Science?");
		hintsDown.add("Down");
		hintsDown.add("1 What is the name of USC’s white\n" + 
				"horse?");
		hintsDown.add("4 What is one of USC’s colors?");
		hintsDown.add("5 Who is USC’s School of Business\n" + 
				"named after?");
		
		
		gameBoard= new String [13][];
		for (int i = 0; i < 13; i++) {
			gameBoard[i] = new String[13];
		}
		
		for (int i = 0; i < 13; i++) {
			for (int j = 0; j < 13; j++) {
				gameBoard[i][j] = "   ";
			}
		}
		gameBoard[0][8] = " 5_";
		gameBoard[1][8] = "  _";
		gameBoard[2][8] = "  _";
		gameBoard[3][8] = "  _";
		gameBoard[4][8] = "  _";
		
		gameBoard[5][8] = "  _";
		gameBoard[6][8] = "  _";
		gameBoard[7][8] = "  _";
		gameBoard[3][7] = " 3_";
		gameBoard[3][9] = "  _";
		gameBoard[3][10] = "  _";
		
		
		gameBoard[5][4] = " 1_";
		gameBoard[5][5] = "  _";
		gameBoard[5][6] = "  _";
		gameBoard[5][7] = "  _";
		gameBoard[5][8] = "  _";
		gameBoard[5][9] = "  _";
		gameBoard[5][10] = "  _";
		
		gameBoard[4][6] = " 4_";
		gameBoard[6][6] = "  _";
		gameBoard[7][6] = "  _";
		
		gameBoard[6][4] = "  _";
		gameBoard[7][4] = "  _";
		gameBoard[8][4] = "  _";
		gameBoard[9][4] = "  _";
		gameBoard[10][4] = "  _";
		gameBoard[11][4] = "  _";
		gameBoard[12][4] = "  _";
		
		gameBoard[11][0] = " 2_";
		gameBoard[11][1] = "  _";
		gameBoard[11][2] = "  _";
		gameBoard[11][3] = "  _";
		gameBoard[11][5] = "  _";
		gameBoard[11][6] = "  _";
		
		
	}
	public void correctguess(String str) {
		if (str.equalsIgnoreCase("trojans")) {
			// remove from hints list
			Iterator<String> itr = hintsAcross.iterator();
			while (itr.hasNext()) 
			{ 
	            String x = (String)itr.next(); 
	            if (x.contains("mascot?")) {
	            	itr.remove();
	            } 
	        }
			gameBoard[5][4] = " 1T";
			gameBoard[5][5] = "  R";
			gameBoard[5][6] = "  O";
			gameBoard[5][7] = "  J";
			gameBoard[5][8] = "  A";
			gameBoard[5][9] = "  N";
			gameBoard[5][10] = "  S";	
		} else if (str.equalsIgnoreCase("dodgers")) {
			Iterator<String> itr = hintsAcross.iterator();
			while (itr.hasNext()) 
			{ 
	            String x = (String)itr.next(); 
	            if (x.equalsIgnoreCase("2 What professional baseball team is\n" + 
	    				"closest to USC?")) {
	            	itr.remove();
	            } 
	        }
			
			gameBoard[11][0] = " 2D";
			gameBoard[11][1] = "  O";
			gameBoard[11][2] = "  D";
			gameBoard[11][3] = "  G";
			gameBoard[11][4] = "  E";
			gameBoard[11][5] = "  R";
			gameBoard[11][6] = "  S";
		} else if (str.equalsIgnoreCase("csci")) {
			Iterator<String> itr = hintsAcross.iterator();
			while (itr.hasNext()) 
			{ 
	            String x = (String)itr.next(); 
	            if (x.equalsIgnoreCase("3 What is the four-letter prefix for\n" + 
	    				"Computer Science?")) {
	            	itr.remove();
	            } 
	        }
			
			gameBoard[3][7] = " 3C";
			gameBoard[3][8] = "  S";
			gameBoard[3][9] = "  C";
			gameBoard[3][10] = "  I";
		} else if (str.equalsIgnoreCase("gold")) {
			Iterator<String> itr = hintsDown.iterator();
			while (itr.hasNext()) 
			{ 
	            String x = (String)itr.next(); 
	            if (x.equalsIgnoreCase("4 What is one of USC’s colors?")) {
	            	itr.remove();
	            } 
	        }
			
			gameBoard[4][6] = " 4G";
			gameBoard[5][6] = "  O";
			gameBoard[6][6] = "  L";
			gameBoard[7][6] = "  D";
		} else if (str.equalsIgnoreCase("marshall")) {
			Iterator<String> itr = hintsDown.iterator();
			while (itr.hasNext()) 
			{ 
	            String x = (String)itr.next(); 
	            if (x.equalsIgnoreCase("5 Who is USC’s School of Business\n" + 
	    				"named after?")) {
	            	itr.remove();
	            } 
	        }
			gameBoard[0][8] = " 5M";
			gameBoard[1][8] = "  A";
			gameBoard[2][8] = "  R";
			gameBoard[3][8] = "  S";
			gameBoard[4][8] = "  H";
			gameBoard[5][8] = "  A";
			gameBoard[6][8] = "  L";
			gameBoard[7][8] = "  L";
		} else if (str.equalsIgnoreCase("traveler")) {
			Iterator<String> itr = hintsDown.iterator();
			while (itr.hasNext()) 
			{ 
	            String x = (String)itr.next(); 
	            if (x.equalsIgnoreCase("1 What is the name of USC’s white\n" + 
	    				"horse?")) {
	            	itr.remove();
	            } 
	        }
			gameBoard[5][4] = " 1T";
			gameBoard[6][4] = "  R";
			gameBoard[7][4] = "  A";
			gameBoard[8][4] = "  V";
			gameBoard[9][4] = "  E";
			gameBoard[10][4] = "  L";
			gameBoard[11][4] = "  E";
			gameBoard[12][4] = "  R";
		
		}
		// if hints arraylist is out of hints (only down/across)
		// then just clear it out
		if (hintsDown.size() == 1) hintsDown.remove(0);
		else if (hintsAcross.size() == 1) hintsAcross.remove(0);
		
		
	}
	public String printBoard() {
		String gamestate = "";
		gamestate += "\n";
		for (int i = 0; i < 13; i++) {
			for (int j = 0; j < 13; j++) {
				gamestate += gameBoard[i][j];
			}
			gamestate += "\n";
		}
		gamestate += "\n";
		for (int i = 0; i < hintsAcross.size(); i++) {
			gamestate += hintsAcross.get(i) + "\n";
		}
		for (int i = 0; i < hintsDown.size(); i++) {
			gamestate += hintsDown.get(i) + "\n";
		}
		return gamestate;
	}
	
	public void reprintHints() {
		hintsAcross.add("Across");
		hintsAcross.add("1 What is USC’s mascot?");
		hintsAcross.add("2 What professional baseball team is\n" + 
				"closest to USC?");
		hintsAcross.add("3 What is the four-letter prefix for\n" + 
				"Computer Science?");
		hintsDown.add("Down");
		hintsDown.add("1 What is the name of USC’s white\n" + 
				"horse?");
		hintsDown.add("4 What is one of USC’s colors?");
		hintsDown.add("5 Who is USC’s School of Business\n" + 
				"named after?");
		
	}
	
}
