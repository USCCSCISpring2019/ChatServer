package com.mypackage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Iterator;

public class CrosswordServer extends Thread {

	private int numClients;
	private ServerSocket ss = null;
	private Socket s = null;
	InputStreamReader isr = null;
	private PrintWriter toClient = null;
	private BufferedReader fromClient = null;
	ArrayList<Client> players_ = null;
	GameBoard gb = null;
	private boolean gameOver;
	ArrayList<String> acrossAvail = null;
	ArrayList<String> downAvail = null;
	
	public CrosswordServer() {
		try {
			ss = new ServerSocket(3456);
		} catch (IOException e) {
			System.out.println("Error opening server socket 3456. Exiting..");
		}
	}

	private synchronized void generateBoard() {
		System.out.println("Reading random game file.");
		gb = new GameBoard();
		System.out.println("File read successfully.");
		acrossAvail = new ArrayList<>();
		acrossAvail.add("1");
		acrossAvail.add("2");
		acrossAvail.add("3");
		downAvail = new ArrayList<>();
		downAvail.add("1");
		downAvail.add("4");
		downAvail.add("5");	
	}
	
	
	private void newGame() {
		gameOver = false;
		numClients = 0;
		listenForPlayers();
		// after getting all players, we're ready to play
		// GameBoard has already been generated
		// inside listenForPlayers() to stay consistent with output of HW
		// GameBoard is stored in gb
		int playerTurnIndex = 0;
		while (!gameOver && playerTurnIndex < 100) {
			System.out.println("Sending game board.");
			System.out.println("Player " + (playerTurnIndex + 1) + "'s turn.");
			for (int i = 0; i < players_.size(); i++) {
				toClient = players_.get(i).toClient;
				toClient.println(gb.printBoard());
				if (i != playerTurnIndex) {
					toClient.println("Player " + (playerTurnIndex + 1) + "'s turn.");
				}
			}
			// broadcast to current player
			
			toClient = players_.get(playerTurnIndex).toClient;
			fromClient = players_.get(playerTurnIndex).fromClient;
			toClient.println("Would you like to answer a question\n" + 
					"across (a) or down (d)?");
			try {
				String response = fromClient.readLine();
				boolean upOrDownAskedSuccess = false;
				boolean questionAskedSuccess = false;
				while (!upOrDownAskedSuccess) {
					
				if (response.equalsIgnoreCase("a") && acrossAvail.size() != 0) {
					upOrDownAskedSuccess = true;
					while (!questionAskedSuccess) {
						toClient.println("Which number?");
						response = fromClient.readLine();
						if (acrossAvail.contains(response)) {
							toClient.println("What is your guess for " + response + " across?");
							String guess = fromClient.readLine();
							if (response.equalsIgnoreCase("1")) {
								if (guess.equals("trojans")) {
									toClient.println("That is correct!");
									// fill in the world on puzzle
									gb.correctguess("trojans");
									players_.get(playerTurnIndex).addPoint();
									// remove from avail list
									Iterator<String> itr = acrossAvail.iterator(); 
							        while (itr.hasNext()) 
							        { 
							            String x = (String)itr.next(); 
							            if (x.equals("1")) {
							            	itr.remove();
							            } 
							        }
							        
							        // Server print
							        System.out.println("Player " + (playerTurnIndex + 1) + " guessed \""+guess+"\" for " + response+ " across.");
							        System.out.println("That is correct.");
							        
							        // broadcast guess to all other players
									for (int i = 0; i < players_.size(); i++) {
										toClient = players_.get(i).toClient;
										if (i != playerTurnIndex) {
											toClient.println("Player " + (playerTurnIndex + 1) + " guessed \""+guess+"\" for " + response+ " across.");
											toClient.println("That is correct.");
										}
									}
									// player goes again
							        --playerTurnIndex;
								}
								else {
									// incorrect guess
									System.out.println("Player " + (playerTurnIndex + 1) + " guessed \""+guess+"\" for " + response+ " across.");
									System.out.println("That is incorrect.");
									toClient.println("That is incorrect!");
									for (int i = 0; i < players_.size(); i++) {
										toClient = players_.get(i).toClient;
										if (i != playerTurnIndex) {
											toClient.println("Player " + (playerTurnIndex + 1) + " guessed \""+guess+"\" for " + response+ " across.");
											toClient.println("That is incorrect.");
										}
									}
								}
							}
							else if (response.equals("2")) {
								if (guess.equals("dodgers")) {
									toClient.println("That is correct!");
									// fill in the world on puzzle
									gb.correctguess("dodgers");
									players_.get(playerTurnIndex).addPoint();
									// remove from avail list
									Iterator<String> itr = acrossAvail.iterator(); 
							        while (itr.hasNext()) 
							        { 
							            String x = (String)itr.next(); 
							            if (x.equals("2")) {
							            	itr.remove();
							            } 
							        }
							        // Server print
							        System.out.println("Player " + (playerTurnIndex + 1) + " guessed \""+guess+"\" for " + response+ " across.");
							        System.out.println("That is correct.");
							        
							        // broadcast correct guess to all other players
									for (int i = 0; i < players_.size(); i++) {
										toClient = players_.get(i).toClient;
										if (i != playerTurnIndex) {
											toClient.println("Player " + (playerTurnIndex + 1) + " guessed \""+guess+"\" for " + response+ " across.");
											toClient.println("That is correct.");
										}
										
									}
									// player goes again
							        --playerTurnIndex;
								}
								else {
									System.out.println("Player " + (playerTurnIndex + 1) + " guessed \""+guess+"\" for " + response+ " across.");
									System.out.println("That is incorrect.");
									// wrong guess
									toClient.println("That is incorrect!");
									for (int i = 0; i < players_.size(); i++) {
										toClient = players_.get(i).toClient;
										if (i != playerTurnIndex) {
											toClient.println("Player " + (playerTurnIndex + 1) + " guessed \""+guess+"\" for " + response+ " across.");
											toClient.println("That is incorrect.");
										}
									}
								}
							}
							else if (response.equals("3")) {
								if (guess.equals("csci")) {
									toClient.println("That is correct!");
									// fill in the world on puzzle
									gb.correctguess("csci");
									players_.get(playerTurnIndex).addPoint();
									// remove from avail list
									Iterator<String> itr = acrossAvail.iterator(); 
							        while (itr.hasNext()) 
							        { 
							            String x = (String)itr.next(); 
							            if (x.equals("3")) {
							            	itr.remove();
							            } 
							        }
							        // Server print
							        System.out.println("Player " + (playerTurnIndex + 1) + " guessed \""+guess+"\" for " + response+ " across.");
							        System.out.println("That is correct.");
							        
							        // broadcast correct guess to all other players
									for (int i = 0; i < players_.size(); i++) {
										toClient = players_.get(i).toClient;
										if (i != playerTurnIndex) {
											toClient.println("Player " + (playerTurnIndex + 1) + " guessed \""+guess+"\" for " + response+ " across.");
											toClient.println("That is correct.");   
										}
									}
									// player goes again
							        --playerTurnIndex;
								}
								else {
									System.out.println("Player " + (playerTurnIndex + 1) + " guessed \""+guess+"\" for " + response+ " across.");
									System.out.println("That is incorrect.");
									// incorrect guess
									toClient.println("That is incorrect!");
									for (int i = 0; i < players_.size(); i++) {
										toClient = players_.get(i).toClient;
										if (i != playerTurnIndex) {
											toClient.println("Player " + (playerTurnIndex + 1) + " guessed \""+guess+"\" for " + response+ " across.");
											toClient.println("That is incorrect.");
										}
									}
								}
							}
							
							questionAskedSuccess = true;
						}
						else {
							toClient.println("That is not a valid option.");
						}
					}
				}
				else if(response.equalsIgnoreCase("d") && downAvail.size() != 0)
				{
					upOrDownAskedSuccess = true;
					while (!questionAskedSuccess) {
						toClient.println("Which number?");
						response = fromClient.readLine();
						if (downAvail.contains(response)) {
							toClient.println("What is your guess for " + response + " down?");
							String guess = fromClient.readLine();
							if (response.equalsIgnoreCase("1")) {
								if (guess.equals("traveler")) {
									toClient.println("That is correct!");
									// fill in the world on puzzle
									gb.correctguess("traveler");
									players_.get(playerTurnIndex).addPoint();
									// remove from avail list
									Iterator<String> itr = downAvail.iterator(); 
							        while (itr.hasNext()) 
							        { 
							            String x = (String)itr.next(); 
							            if (x.equals("1")) {
							            	itr.remove();
							            } 
							        }
							        // Server print
							        System.out.println("Player " + (playerTurnIndex + 1) + " guessed \""+guess+"\" for " + response+ " across.");
							        System.out.println("That is correct.");
							        
							        // broadcast guess to all other players
									for (int i = 0; i < players_.size(); i++) {
										toClient = players_.get(i).toClient;
										if (i != playerTurnIndex) {
											toClient.println("Player " + (playerTurnIndex + 1) + " guessed \""+guess+"\" for " + response+ " down.");
											toClient.println("That is correct.");
										}
									}
									// player goes again
							        --playerTurnIndex;
								}
								else {
									System.out.println("Player " + (playerTurnIndex + 1) + " guessed \""+guess+"\" for " + response+ " across.");
									System.out.println("That is incorrect.");
									// incorrect guess
									toClient.println("That is incorrect!");
									for (int i = 0; i < players_.size(); i++) {
										toClient = players_.get(i).toClient;
										if (i != playerTurnIndex) {
											toClient.println("Player " + (playerTurnIndex + 1) + " guessed \""+guess+"\" for " + response+ " down.");
											toClient.println("That is incorrect.");
										}
									}
								}
							}
							else if (response.equals("4")) {
								if (guess.equals("gold")) {
									toClient.println("That is correct!");
									// fill in the world on puzzle
									gb.correctguess("gold");
									players_.get(playerTurnIndex).addPoint();
									// remove from avail list
									Iterator<String> itr = downAvail.iterator(); 
							        while (itr.hasNext()) 
							        { 
							            String x = (String)itr.next(); 
							            if (x.equals("4")) {
							            	itr.remove();
							            } 
							        }
							        // Server print
							        System.out.println("Player " + (playerTurnIndex + 1) + " guessed \""+guess+"\" for " + response+ " across.");
							        System.out.println("That is correct.");
							        
							        // broadcast correct guess to all other players
									for (int i = 0; i < players_.size(); i++) {
										toClient = players_.get(i).toClient;
										if (i != playerTurnIndex) {
											toClient.println("Player " + (playerTurnIndex + 1) + " guessed \""+guess+"\" for " + response+ " down.");
											toClient.println("That is correct.");
										}
										
									}
									// player goes again
							        --playerTurnIndex;
								}
								else {
									System.out.println("Player " + (playerTurnIndex + 1) + " guessed \""+guess+"\" for " + response+ " across.");
									System.out.println("That is incorrect.");
									// wrong guess
									toClient.println("That is incorrect!");
									for (int i = 0; i < players_.size(); i++) {
										toClient = players_.get(i).toClient;
										if (i != playerTurnIndex) {
											toClient.println("Player " + (playerTurnIndex + 1) + " guessed \""+guess+"\" for " + response+ " down.");
											toClient.println("That is incorrect.");
										}
									}
								}
							}
							else if (response.equals("5")) {
								if (guess.equals("marshall")) {
									toClient.println("That is correct!");
									// fill in the world on puzzle
									gb.correctguess("marshall");
									players_.get(playerTurnIndex).addPoint();
									// remove from avail list
									Iterator<String> itr = downAvail.iterator(); 
							        while (itr.hasNext()) 
							        { 
							            String x = (String)itr.next(); 
							            if (x.equals("5")) {
							            	itr.remove();
							            } 
							        }
							        // Server print
							        System.out.println("Player " + (playerTurnIndex + 1) + " guessed \""+guess+"\" for " + response+ " across.");
							        System.out.println("That is correct.");
							        
							        // broadcast correct guess to all other players
									for (int i = 0; i < players_.size(); i++) {
										toClient = players_.get(i).toClient;
										if (i != playerTurnIndex) {
											toClient.println("Player " + (playerTurnIndex + 1) + " guessed \""+guess+"\" for " + response+ " down.");
											toClient.println("That is correct.");   
										}
									}
									// player goes again
							        --playerTurnIndex;
								}
								else {
									System.out.println("Player " + (playerTurnIndex + 1) + " guessed \""+guess+"\" for " + response+ " across.");
									System.out.println("That is incorrect.");
									// incorrect guess
									toClient.println("That is incorrect!");
									for (int i = 0; i < players_.size(); i++) {
										toClient = players_.get(i).toClient;
										if (i != playerTurnIndex) {
											toClient.println("Player " + (playerTurnIndex + 1) + " guessed \""+guess+"\" for " + response+ " down.");
											toClient.println("That is incorrect.");
										}
									}
								}
							}
							questionAskedSuccess = true;
						}
						else {
							toClient.println("That is not a valid option.");
							
						}
					}
				}
				else {
					toClient.println("That is not a valid option.");
					toClient.println("Would you like to answer a question\n" + 
							"across (a) or down (d)?");
					response = fromClient.readLine();
				}
				}
				
			} catch (IOException ioe) {
				System.out.println("ioe = " + ioe.getMessage());
			}
			
			
			
			playerTurnIndex = (++playerTurnIndex) % players_.size();
			if (acrossAvail.isEmpty() && downAvail.isEmpty()) {
				// Game over
				System.out.println("The game has concluded.");
				System.out.println("Sending scores.");
				
				gameOver = true;
				for (int i = 0; i < players_.size(); i++) {
					toClient = players_.get(i).toClient;
					gb.reprintHints();
					toClient.println(gb.printBoard());
					
					toClient.println("");
					toClient.println("Final Score");
					int currentmaxpoints = 0;
					int currentwinningplayer = 0;
					boolean tie = false;
					ArrayList<Integer> winningPlayers = new ArrayList<Integer>();
					for (int j = 0; j < players_.size(); j++) {
						int points = players_.get(j).getpoints();
						if (points > currentmaxpoints) { 
							tie = false;
							winningPlayers.clear();
							currentmaxpoints = points;
							currentwinningplayer = j+1;
							winningPlayers.add(j+1);
						} else if (points == currentmaxpoints) {
							tie = true;
							winningPlayers.add(j+1);
							
						}
						toClient.println("Player " + (j+1) + " - " + points + " correct answers.");
					}
					toClient.println("");
					if (!tie) {
						toClient.println("Player " + currentwinningplayer + " is the winner.");
					} else {
						if (winningPlayers.size() == 2) {
							toClient.println("There is a two-way tie between Player " + winningPlayers.get(0) + " and Player " + winningPlayers.get(1) + ".");
						}
						else {
							toClient.println("There is a three-way tie between all three Players.");
						}
					}
					// close all client sockets
					for (int k = 0; k < players_.size(); k++) {
						Client c = players_.get(k);
						c.close();
					}
				}
			}
		}
	}
	
	private void listenForPlayers() {
		// going to block-wait for new clients
		// the first one is unique
		try {
			System.out.println("Waiting for players...");
			s = ss.accept();
			System.out.println("Connection from " + s.getInetAddress());
			isr = new InputStreamReader(s.getInputStream());
			fromClient = new BufferedReader(isr);
			toClient = new PrintWriter(s.getOutputStream(), true);
			
			
			Client c = new Client(s, fromClient, toClient);
			players_ = new ArrayList<Client>();
			players_.add(c);
			toClient.println("How many players will there be?");
			numClients = Integer.parseInt(fromClient.readLine());
			System.out.println("Number of players: " + numClients);
			if (numClients != 1) { 
				while (players_.size() != numClients) {
					System.out.println("Waiting for player " + (players_.size() + 1) + ".");
					for (int i = 0; i < players_.size(); i++) {
						toClient = players_.get(i).toClient;
						toClient.println("Waiting for player " + (players_.size() + 1) + ".");
					}
					if (players_.size() == 1) {
						generateBoard();
					}
					s = ss.accept();
					System.out.println("Connection from " + s.getInetAddress());
					for (int i = 0; i < players_.size(); i++) { 
						// send message to existing clients
						toClient = players_.get(i).toClient;
						toClient.println("Connection from " + s.getInetAddress());
					}
					isr = new InputStreamReader(s.getInputStream());
					fromClient = new BufferedReader(isr);
					toClient = new PrintWriter(s.getOutputStream(), true);
					c = new Client(s, fromClient, toClient);
					// send message to client that just joined existing game
					toClient.println("There is a game waiting for you.");
					for (int i = 0; i < players_.size(); i++) {
						toClient.println ("Player " + (i + 1) + " has already joined.");
					}
					players_.add(c);
					
				}
			}
			else {
				
				generateBoard();
			}
			System.out.println("Game can now begin.");

			for (int i = 0; i < players_.size(); i++) { 
				toClient = players_.get(i).toClient;
				toClient.println("The game is beginning");
			}
			
		}
		catch (IOException e) {
			System.out.println(e.getMessage());
			
		}
	}
	
	public static void main(String[] args) {
		CrosswordServer cs = new CrosswordServer();
		while (true) {
			cs.newGame();
		}
	}
	public class Client {
		Client(Socket st, BufferedReader fromClient, PrintWriter toClient) {
			s_ = st;
			this.fromClient = fromClient;
			this.toClient = toClient;
		}
		public Socket s_;
		public BufferedReader fromClient = null;
		public PrintWriter toClient = null;
		public int points;
		public void addPoint() {
			points++;
		}
		int getpoints() {
			return points;
		}
		public void close() {
			try {
				fromClient.close();
				toClient.close();
				s_.close();
			} catch (IOException ioe) {
				System.out.println("ioe = " + ioe.getMessage());
			}
		}
		
	}

}









