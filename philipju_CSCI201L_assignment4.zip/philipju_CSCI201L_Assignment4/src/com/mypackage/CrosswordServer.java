package com.mypackage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

public class CrosswordServer {

	private int numClients;
	private ServerSocket ss = null;
	private Socket s = null;
	private Scanner scanner = new Scanner(System.in);
	InputStreamReader isr = null;
	private PrintWriter toClient = null;
	private BufferedReader fromClient = null;
	ArrayList<Client> players_;
	
	
	@SuppressWarnings("unused")
	public CrosswordServer() {
		try {
			ss = new ServerSocket(3456);
		} catch (IOException e) {
			System.out.println("Error opening server socket 3456. Exiting..");
		}
	}

	private void generateBoard() {
		
	}
	
	
	private void newGame() {
		listenForPlayers();
		// after getting all players, we're ready to play
		
	}
	
	private void listenForPlayers() {
		// going to block-wait for new clients
		// the first one is unique
		try {
			System.out.println("Waiting for players...");
			s = ss.accept();
			System.out.println("Connection from " + s.getInetAddress());
			isr = new InputStreamReader(s.getInputStream());
			fromClient = new BufferedReader(isr);
			toClient = new PrintWriter(s.getOutputStream(), true);
			
			
			Client c = new Client(s, fromClient, toClient);
			players_ = new ArrayList<Client>();
			players_.add(c);
			toClient.println("How many players will there be?");
			numClients = Integer.parseInt(fromClient.readLine());
			System.out.println("Number of players: " + numClients);
			if (numClients != 1) { 
				while (players_.size() != numClients) {
					System.out.println("Waiting for player " + (players_.size() + 1) + ".");
					for (int i = 0; i < players_.size(); i++) {
						toClient = players_.get(i).toClient;
						toClient.println("Waiting for player " + (players_.size() + 1) + ".");
					}
					System.out.println("Reading random game file.");
					// write code to read random game file
					// private void generateBoard();
					s = ss.accept();
					System.out.println("Connection from " + s.getInetAddress());
					for (int i = 0; i < players_.size(); i++) { 
						// send message to existing clients
						toClient = players_.get(i).toClient;
						toClient.println("Connection from " + s.getInetAddress());
					}
					isr = new InputStreamReader(s.getInputStream());
					fromClient = new BufferedReader(isr);
					toClient = new PrintWriter(s.getOutputStream(), true);
					c = new Client(s, fromClient, toClient);
					// send message to client that just joined existing game
					toClient.println("There is a game waiting for you.");
					for (int i = 0; i < players_.size(); i++) {
						toClient.println ("Player " + (i + 1) + " has already joined.");
					}
					players_.add(c);
					
				}
			}
			else {
				// Solo game, just generate board
				System.out.println("Reading random game file.");
				// write code to read random game file
				// private void generateBoard();
			}
			System.out.println("Game can now begin.");
			System.out.println("Sending game board.");
			for (int i = 0; i < players_.size(); i++) { 
				toClient = players_.get(i).toClient;
				toClient.println("The game is beginning");
			}
			
		}
		catch (IOException e) {
			System.out.println(e.getMessage());
			
		}
	}
	
	public static void main(String[] args) {
		CrosswordServer cs = new CrosswordServer();
		cs.newGame();
		

	}
	public class Client {
		Client(Socket st, BufferedReader fromClient, PrintWriter toClient) {
			s_ = st;
			this.fromClient = fromClient;
			this.toClient = toClient;
		}
		public Socket s_;
		public BufferedReader fromClient = null;
		public PrintWriter toClient = null;
		
	}

}









