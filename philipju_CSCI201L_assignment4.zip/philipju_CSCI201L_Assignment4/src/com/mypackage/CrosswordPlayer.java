package com.mypackage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class CrosswordPlayer extends Thread {
	
	private Scanner scanner = new Scanner(System.in);
	private Socket s = null;
	private boolean accepted;
	private BufferedReader fromServer = null;
	private InputStreamReader isr = null;
	private PrintWriter toServer = null;
	
	CrosswordPlayer() {
		accepted = false;
		while (!accepted) {
			try {
				System.out.println("Welcome to 201 Crossword!");
				System.out.print("Enter the server hostname:");
				String ip = scanner.nextLine();
				System.out.print("\nEnter the server port:");
				String portStr = scanner.nextLine();
				int port = Integer.parseInt(portStr);
				s = new Socket(ip, port);
				// on this line, connection successful
				accepted = true;
			} catch (Exception e) {
				System.out.println("Could not connect to that hostname:port");
				accepted = false;
			}
			
		}
		try {
			isr = new InputStreamReader(s.getInputStream());
			fromServer = new BufferedReader(isr);
			toServer = new PrintWriter(s.getOutputStream(), true);
						
			// get initial message from Server
			String line = fromServer.readLine();
			System.out.println(line);
			
			// send response below
			// if line is a question, need to send a response
			// if not, just wait for game to start
			if (line.equals("How many players will there be?")) {
				String response = scanner.nextLine();
				while (true) {
					try {
						int numPlayers = Integer.parseInt(response);
						if (numPlayers >=1 && numPlayers <= 3) {
							break;
						} else {
							System.out.println("Please enter 1 through 3.");
							System.out.println("How many players will there be?");
							response = scanner.nextLine();
						}
					} catch (NumberFormatException e){
						System.out.println("Please enter 1 through 3.");
						System.out.println("How many players will there be?");
						response = scanner.nextLine();
						continue;
					}
				}
				toServer.println(response);
			} 
			// whether one player or not
			// just wait for game to start now
			while (!line.equals("The game is beginning")) {
				line = fromServer.readLine();
				System.out.println(line);
			}
			
		} catch (IOException e) {
			System.out.println("ioe = " + e.getMessage());
		} 
		
			
	}
	public synchronized void playGame() {
		// if here, then game is starting
		// Either i just received an announcement or its my turn to play here
		try {
			String line = null;
			String response = null;
			while ((line = fromServer.readLine()) != null) {
			    System.out.println(line);
				if (line.equals("across (a) or down (d)?")) {
					response = scanner.nextLine();
					toServer.println(response);
				} else if (line.equals("Which number?")) {
					response = scanner.nextLine();
					toServer.println(response);
				} else if (line.contains("What is your")) {
					// here, the Client is ready to guess a word
					response = scanner.nextLine();
					toServer.println(response);
				}	
			}
		} catch (IOException ioe) {
			System.out.println("ioe = " + ioe.getMessage());
		} finally {
			try {
				fromServer.close();
				toServer.close();
				s.close();
			} catch (IOException ioe) {
				System.out.println("ioe = " + ioe.getMessage());
			}
				
		}
	}
	
	public static void main(String[] args) {
		CrosswordPlayer cp = new CrosswordPlayer();
		cp.playGame();
	}

}
